surfaceareacalc Version 3.0
Made by Harris Ransom

This program allows you to choose from a number of surface area calculations (recntangular, spherical, conical) and calculate the surface area according to the given parameters..
If the calculation is incorrect, the calculator will return an "Invalid Calculation" alert. This happens if negative or a 0 appears in one of your dimensions.
This only works for 3D objects (obviously).

If you look into the library on your TI-NSpire, you will see comments that guide you along on how to use the library. 

Thank you, and happy math! 